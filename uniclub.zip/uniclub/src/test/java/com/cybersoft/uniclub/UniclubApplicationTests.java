package com.cybersoft.uniclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniclubApplicationTests {

	@Test
	void contextLoads() {
	}

}
